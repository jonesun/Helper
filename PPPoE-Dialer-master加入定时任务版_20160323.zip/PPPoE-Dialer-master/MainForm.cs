﻿/*
 * 用户： fuyumi
 * 日期: 2015/10/25 星期日
 * 时间: 下午 9:07
 */

using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using DotRas;
using System.ComponentModel;
using System.Configuration;

namespace pppoe_dialer
{
	public partial class MainForm : Form
	{
        private static double ConnectInterval = 1000 * 30; //定时拨号时间
        private static double DisconnectInterval = 1000 * 50; //定时断开时间
        private bool isConnect = false; //当前状态(是否连接)
        private string username;
        private string password;

        //使用多线程计时器
        private System.Timers.Timer timer = new System.Timers.Timer();
        BackgroundWorker bgWorker = new BackgroundWorker();

        public MainForm()
		{
			InitializeComponent();
            AccessAppSettings();
            CreateConnect("PPPoEDial");
			btn_Hungup.Enabled = false;
		}
				
		public void CreateConnect(string ConnectName)
		{
			RasDialer dialer = new RasDialer();
			RasPhoneBook book = new RasPhoneBook();
			try {
				book.Open(RasPhoneBook.GetPhoneBookPath(RasPhoneBookType.User));
				if (book.Entries.Contains(ConnectName)) {
					book.Entries[ConnectName].PhoneNumber = " ";
					book.Entries[ConnectName].Update();
				} else {
					ReadOnlyCollection<RasDevice> readOnlyCollection = RasDevice.GetDevices();
					RasDevice device = RasDevice.GetDevices().Where(o => o.DeviceType == RasDeviceType.PPPoE).First();
					RasEntry entry = RasEntry.CreateBroadbandEntry(ConnectName, device);
					entry.PhoneNumber = " ";
					book.Entries.Add(entry);
				}
                initTimerAndBgWorker();
            } catch (Exception) {
				lb_Status.Text = "创建PPPoE连接失败";
			}
            Username.Text = username;
            Password.Text = password;
        }
		
		void Btn_DialupClick(object sender, EventArgs e)
		{
            username = Username.Text.Replace("\\r", "\r").Replace("\\n", "\n");
            password = Password.Text.ToString();
            connect();
        }
		
		void Btn_HungupClick(object sender, EventArgs e){
            disconnect(true);
        }

        private void connect() {
            isConnect = true;
            timer.Stop();
            try
            {
                RasDialer dialer = new RasDialer();
                dialer.EntryName = "PPPoEDial";
                dialer.PhoneNumber = " ";
                dialer.AllowUseStoredCredentials = true;
                dialer.PhoneBookPath = RasPhoneBook.GetPhoneBookPath(RasPhoneBookType.User);
                dialer.Credentials = new NetworkCredential(username, password);
                dialer.Timeout = 1000;
                RasHandle myras = dialer.Dial();
                while (myras.IsInvalid)
                {
                    lb_Status.Text = "拨号失败";
                }
                if (!myras.IsInvalid)
                {
                    lb_Status.Text = "拨号成功! ";
                    RasConnection conn = RasConnection.GetActiveConnectionByHandle(myras);
                    RasIPInfo ipaddr = (RasIPInfo)conn.GetProjectionInfo(RasProjectionType.IP);
                    lb_IPAddr.Text = "获得IP： " + ipaddr.IPAddress.ToString();
                    btn_Dialup.Enabled = false;
                    btn_Hungup.Enabled = true;
                    timer.Interval = DisconnectInterval;
                    timer.Start();
                }
            }
            catch (Exception)
            {
                lb_Status.Text = "拨号出现异常";
            }
        }

        private void disconnect(bool isEnd) {
            isConnect = false;
            timer.Stop();
            try
            {
                ReadOnlyCollection<RasConnection> conList = RasConnection.GetActiveConnections();
                foreach (RasConnection con in conList)
                {
                    con.HangUp();
                }
                Thread.Sleep(1000);
                lb_Status.Text = "注销成功";
                lb_IPAddr.Text = "已注销";
                btn_Dialup.Enabled = true;
                btn_Hungup.Enabled = false;
                if (!isEnd) {
                    timer.Interval = ConnectInterval;
                    timer.Start();
                }
            }
            catch (Exception)
            {
                lb_Status.Text = "注销出现异常";
            }
        }

        void initTimerAndBgWorker() {
            bgWorker.WorkerReportsProgress = true;
            bgWorker.WorkerSupportsCancellation = true;
            bgWorker.DoWork += DoWork_Handler;
            bgWorker.RunWorkerCompleted += RunWorkerCompleted_Handler;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);
        }

        void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e){
            Console.WriteLine("后台任务执行：" + DateTime.Now.ToLocalTime());
            if (!bgWorker.IsBusy)
            {
                bgWorker.RunWorkerAsync();
            }
        }

        private void DoWork_Handler(object sender, DoWorkEventArgs args){
            BackgroundWorker worker = sender as BackgroundWorker;
        }

        private void RunWorkerCompleted_Handler(object sender, RunWorkerCompletedEventArgs args){
            string content;
            if (args.Cancelled)
            {
                content = "后台任务已经被取消。" + DateTime.Now.ToLocalTime();
            }
            else
            {
                if (isConnect)
                {
                    disconnect(false);
                    content = "断开连接" + DateTime.Now.ToLocalTime();
                }
                else {
                    connect();
                    content = "连接" + DateTime.Now.ToLocalTime();
                }
            }
            Console.WriteLine(content);
        }

        private void AccessAppSettings(){
            string path = Application.StartupPath + "\\AppData.config";
            if (!System.IO.File.Exists(path)) {
                System.IO.File.Create(path);
            }
            //获取Configuration对象
            Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(path);

            ConnectInterval = double.Parse(initProperty(config, "connectInterval", Convert.ToString(1000 * 30))); //默认30s
            DisconnectInterval = double.Parse(initProperty(config, "disconnectInterval", Convert.ToString(1000 * 50))); //默认50s

            username = initProperty(config, "username", "sza417346");
            password = initProperty(config, "password", "68234384");

            config.Save(ConfigurationSaveMode.Modified);
            System.Configuration.ConfigurationManager.RefreshSection("appSettings");
        }

        private string initProperty(Configuration config, string key, string defaultValue) {
            string value = defaultValue;
            if (config.AppSettings.Settings[key] != null)
            {
                value = config.AppSettings.Settings[key].Value;
                if (value == null || value.Length == 0)
                {
                    config.AppSettings.Settings.Add(key, defaultValue);
                    value = defaultValue;
                }
            }
            else {
                config.AppSettings.Settings.Add(key, defaultValue);
            }
            return value;
        }
    }
}
